#pragma once
#include "frameStructs.h"
#include "macros.h"


void printInfoFrame( infoFrame frame);

void printDataFrame( dataFrame frame);

void printControlFrame( controlFrame frame);