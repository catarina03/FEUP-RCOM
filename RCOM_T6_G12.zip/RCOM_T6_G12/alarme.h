#pragma once

void setAlarm();

int getAlarmFlag();

int getAlarmCounter();

void setAlarmFlag(int flag);

void setAlarmCounter(int count);

void resetAlarm();
